Contributing to the MongoDB project
===================================

Pull requests are always welcome, and the MongoDB dev team appreciates any help the community can
give to help make MongoDB better.

For more information about how to contribute, please read `the MongoDB Wiki on GitHub`_.

.. _the MongoDB Wiki on GitHub: https://github.com/mongodb/mongo/wiki
